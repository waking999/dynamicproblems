package au.edu.cdu.dynamicproblems.io;

public interface DBOperation {

}
