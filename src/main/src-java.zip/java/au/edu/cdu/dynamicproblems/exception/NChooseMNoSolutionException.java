package au.edu.cdu.dynamicproblems.exception;

public class NChooseMNoSolutionException extends Exception {
	private static final long serialVersionUID = 1L;
	

	public NChooseMNoSolutionException(String msg){
		super(msg);
	}
}