package au.edu.cdu.dynamicproblems.algorithm;

public interface IAlgorithm {

}
