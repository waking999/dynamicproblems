package au.edu.cdu.dynamicproblems.io;

public class FileInfo {
	String inputFile;
	String operationFile;
	public String getInputFile() {
		return inputFile;
	}
	public void setInputFile(String inputFile) {
		this.inputFile = inputFile;
	}
	public String getOperationFile() {
		return operationFile;
	}
	public void setOperationFile(String operationFile) {
		this.operationFile = operationFile;
	}
}
