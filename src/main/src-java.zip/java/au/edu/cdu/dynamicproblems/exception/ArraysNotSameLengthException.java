package au.edu.cdu.dynamicproblems.exception;

public class ArraysNotSameLengthException extends Exception {
	private static final long serialVersionUID = 1L;
	

	public ArraysNotSameLengthException(String msg){
		super(msg);
	}
}
