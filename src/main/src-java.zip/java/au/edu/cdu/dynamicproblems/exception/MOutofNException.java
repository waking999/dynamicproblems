package au.edu.cdu.dynamicproblems.exception;

public class MOutofNException extends Exception {
	private static final long serialVersionUID = 1L;
	

	public MOutofNException(String msg){
		super(msg);
	}
}
